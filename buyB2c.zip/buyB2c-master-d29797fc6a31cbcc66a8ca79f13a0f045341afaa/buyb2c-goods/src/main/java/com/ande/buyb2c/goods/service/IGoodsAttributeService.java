package com.ande.buyb2c.goods.service;

import java.util.List;

import com.ande.buyb2c.common.util.IBaseService;
import com.ande.buyb2c.goods.entity.GoodsAttribute;

/**
 * @author chengzb
 * @date 2018年1月30日上午9:48:38
 */
public interface IGoodsAttributeService extends IBaseService<GoodsAttribute>{
}
