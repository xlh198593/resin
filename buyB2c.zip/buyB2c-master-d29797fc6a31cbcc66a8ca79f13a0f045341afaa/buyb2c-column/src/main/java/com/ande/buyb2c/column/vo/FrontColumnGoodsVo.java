package com.ande.buyb2c.column.vo;
/**
 * @author chengzb
 * @date 2018年2月1日下午4:15:47
 */
public class FrontColumnGoodsVo {
private Integer goodsId;
private String goodsName;
private String mainImage;
private String goodsPrice;
public Integer getGoodsId() {
	return goodsId;
}
public void setGoodsId(Integer goodsId) {
	this.goodsId = goodsId;
}
public String getGoodsName() {
	return goodsName;
}
public void setGoodsName(String goodsName) {
	this.goodsName = goodsName;
}
public String getMainImage() {
	return mainImage;
}
public void setMainImage(String mainImage) {
	this.mainImage = mainImage;
}
public String getGoodsPrice() {
	return goodsPrice;
}
public void setGoodsPrice(String goodsPrice) {
	this.goodsPrice = goodsPrice;
}
}
