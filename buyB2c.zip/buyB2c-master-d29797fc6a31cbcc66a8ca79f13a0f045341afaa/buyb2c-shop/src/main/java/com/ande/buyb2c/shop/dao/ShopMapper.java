package com.ande.buyb2c.shop.dao;

import com.ande.buyb2c.common.util.IBaseDao;
import com.ande.buyb2c.shop.entity.Shop;

public interface ShopMapper extends IBaseDao<Shop>{
}