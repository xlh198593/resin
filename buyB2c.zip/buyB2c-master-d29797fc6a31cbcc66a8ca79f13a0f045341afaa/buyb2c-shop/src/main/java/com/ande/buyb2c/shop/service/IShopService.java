package com.ande.buyb2c.shop.service;

import com.ande.buyb2c.common.util.IBaseService;
import com.ande.buyb2c.shop.entity.Shop;

/**
 * @author chengzb
 * @date 2018年1月27日下午2:26:18
 */
public interface IShopService extends IBaseService<Shop> {

}
