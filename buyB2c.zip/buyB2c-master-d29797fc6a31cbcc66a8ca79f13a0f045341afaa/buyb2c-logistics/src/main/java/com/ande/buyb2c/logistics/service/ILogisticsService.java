package com.ande.buyb2c.logistics.service;

import com.ande.buyb2c.common.util.IBaseService;
import com.ande.buyb2c.logistics.entity.Logistics;

/**
 * @author chengzb
 * @date 2018年1月27日上午9:15:21
 */
public interface ILogisticsService extends IBaseService<Logistics> {

}
