package com.ande.buyb2c.logistics.dao;


import com.ande.buyb2c.common.util.IBaseDao;
import com.ande.buyb2c.logistics.entity.Logistics;

public interface LogisticsMapper extends IBaseDao<Logistics>{
}