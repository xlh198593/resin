package com.ande.buyb2c.advert.dao;

import com.ande.buyb2c.advert.entity.AdvertPosition;
import com.ande.buyb2c.common.util.IBaseDao;

public interface AdvertPositionMapper extends IBaseDao<AdvertPosition>{
}