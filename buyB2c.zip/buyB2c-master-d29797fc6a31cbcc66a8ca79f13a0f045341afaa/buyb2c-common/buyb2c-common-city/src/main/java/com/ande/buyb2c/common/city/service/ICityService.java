package com.ande.buyb2c.common.city.service;

import com.ande.buyb2c.common.city.entity.City;
import com.ande.buyb2c.common.util.IBaseService;

/**
 * @author chengzb
 * @date 2018年1月26日下午2:50:26
 */
public interface ICityService extends IBaseService<City> {

}
