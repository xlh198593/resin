package com.ande.buyb2c.common.city.dao;


import com.ande.buyb2c.common.city.entity.Area;
import com.ande.buyb2c.common.util.IBaseDao;


public interface AreaMapper extends IBaseDao<Area>{
}