package com.ande.buyb2c.common.city.dao;

import com.ande.buyb2c.common.city.entity.Province;
import com.ande.buyb2c.common.util.IBaseDao;

public interface ProvinceMapper extends IBaseDao<Province>{
}