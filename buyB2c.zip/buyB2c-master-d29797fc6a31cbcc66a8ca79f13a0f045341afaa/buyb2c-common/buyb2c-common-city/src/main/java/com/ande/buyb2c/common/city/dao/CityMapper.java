package com.ande.buyb2c.common.city.dao;

import com.ande.buyb2c.common.city.entity.City;
import com.ande.buyb2c.common.util.IBaseDao;

public interface CityMapper extends IBaseDao<City>{
}