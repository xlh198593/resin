package com.ande.buyb2c.order.dao;

import com.ande.buyb2c.common.util.IBaseDao;
import com.ande.buyb2c.order.entity.RefundOrder;

public interface RefundOrderMapper extends IBaseDao<RefundOrder>{

}