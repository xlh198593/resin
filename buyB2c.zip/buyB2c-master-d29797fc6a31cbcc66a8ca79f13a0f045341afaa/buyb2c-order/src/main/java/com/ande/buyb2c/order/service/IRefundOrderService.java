package com.ande.buyb2c.order.service;

import com.ande.buyb2c.common.util.IBaseService;
import com.ande.buyb2c.order.entity.RefundOrder;

/**
 * @author chengzb
 * @date 2018年2月6日下午2:01:50
 */
public interface IRefundOrderService extends IBaseService<RefundOrder> {

}
