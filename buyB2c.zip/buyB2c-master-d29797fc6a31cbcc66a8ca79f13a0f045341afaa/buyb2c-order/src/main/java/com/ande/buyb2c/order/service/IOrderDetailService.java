package com.ande.buyb2c.order.service;

import com.ande.buyb2c.common.util.IBaseService;
import com.ande.buyb2c.order.entity.OrderDetail;

/**
 * @author chengzb
 * @date 2018年3月9日下午6:22:42
 */
public interface IOrderDetailService extends IBaseService<OrderDetail> {

}
